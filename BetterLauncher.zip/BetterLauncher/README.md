# BetterLauncher

Minecraft Java launcher for iPhone and iPad. Early skeleton: interface and Mojang version list only. It does not run Minecraft yet.

## Put it on GitHub (from a browser)
1. Unzip BetterLauncher.zip on your device.
2. In your new GitHub repo: Add file > Upload files, and drag in everything inside the unzipped folder (the BetterLauncher folder, Config folder, project.yml, README.md, .gitignore).
3. The hidden `.github` folder often doesn't upload. Instead use Add file > Create new file, type `.github/workflows/build-ipa.yml` as the name, paste in the contents of that file, and commit.

## Build
Open the repo's Actions tab > "Build IPA". It runs on every push to `main`, or press Run workflow. When it finishes (about 5 minutes), open the run and download `BetterLauncher-ipa` from Artifacts. If it fails, download `xcodebuild-log` and send it to Claude.

## Install
Unzip the artifact to get `BetterLauncher.ipa`, then open it in SideStore (or AltStore) to install. The IPA is unsigned; SideStore signs it with your Apple ID.
