import Foundation

/// Mirrors Mojang's version_manifest_v2.json (only the fields we use).
struct VersionManifest: Decodable {
    struct Latest: Decodable {
        let release: String
        let snapshot: String
    }

    struct Entry: Decodable, Identifiable, Hashable {
        let id: String
        let type: String
        let url: URL
        let releaseTime: String
    }

    let latest: Latest
    let versions: [Entry]
}
