import Foundation

@MainActor
final class VersionStore: ObservableObject {
    enum LoadState: Equatable {
        case idle
        case loading
        case loaded
        case failed(String)
    }

    @Published private(set) var loadState: LoadState = .idle
    @Published private(set) var versions: [VersionManifest.Entry] = []
    @Published private(set) var latestRelease: String?
    @Published var selectedID: String? {
        didSet { UserDefaults.standard.set(selectedID, forKey: Self.selectedKey) }
    }

    private static let selectedKey = "selectedVersionID"
    private static let manifestURL = URL(
        string: "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"
    )!

    init() {
        selectedID = UserDefaults.standard.string(forKey: Self.selectedKey)
    }

    func load() async {
        if loadState == .loading { return }
        loadState = .loading
        do {
            let (data, response) = try await URLSession.shared.data(from: Self.manifestURL)
            guard let http = response as? HTTPURLResponse,
                  (200..<300).contains(http.statusCode) else {
                throw URLError(.badServerResponse)
            }
            let manifest = try JSONDecoder().decode(VersionManifest.self, from: data)
            versions = manifest.versions
            latestRelease = manifest.latest.release
            if selectedID == nil {
                selectedID = manifest.latest.release
            }
            loadState = .loaded
        } catch {
            loadState = .failed(error.localizedDescription)
        }
    }
}
