import SwiftUI

struct PlayView: View {
    @EnvironmentObject private var store: VersionStore
    @State private var showEngineAlert = false

    var body: some View {
        NavigationStack {
            VStack(spacing: 24) {
                Spacer()
                Text("BetterLauncher")
                    .font(.largeTitle.bold())
                VStack(spacing: 4) {
                    Text("Selected version")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Text(store.selectedID ?? "None selected")
                        .font(.title2.monospaced())
                }
                Button {
                    showEngineAlert = true
                } label: {
                    Text("Play")
                        .font(.title2.bold())
                        .frame(maxWidth: .infinity)
                        .padding()
                }
                .buttonStyle(.borderedProminent)
                .padding(.horizontal, 40)
                Spacer()
            }
            .navigationTitle("Play")
            .navigationBarTitleDisplayMode(.inline)
            .alert("Game engine not connected yet", isPresented: $showEngineAlert) {
                Button("OK", role: .cancel) {}
            } message: {
                Text("This build only has the launcher interface. Running Minecraft comes in a later step.")
            }
        }
    }
}
