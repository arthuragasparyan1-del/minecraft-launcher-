import SwiftUI
import UIKit

struct SettingsView: View {
    private var deviceMemory: String {
        ByteCountFormatter.string(
            fromByteCount: Int64(ProcessInfo.processInfo.physicalMemory),
            countStyle: .memory
        )
    }

    private var appVersion: String {
        Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "?"
    }

    var body: some View {
        NavigationStack {
            List {
                Section("Device") {
                    LabeledContent("Memory", value: deviceMemory)
                    LabeledContent("System", value: "iOS \(UIDevice.current.systemVersion)")
                }
                Section("About") {
                    LabeledContent("BetterLauncher", value: appVersion)
                }
                Section("Not built yet") {
                    Text("Accounts, mods, controls, Java and performance settings")
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Settings")
        }
    }
}
