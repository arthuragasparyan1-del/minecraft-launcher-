import SwiftUI

struct RootView: View {
    var body: some View {
        TabView {
            PlayView()
                .tabItem { Label("Play", systemImage: "play.fill") }
            VersionsView()
                .tabItem { Label("Versions", systemImage: "square.stack.3d.up") }
            SettingsView()
                .tabItem { Label("Settings", systemImage: "gearshape") }
        }
    }
}
