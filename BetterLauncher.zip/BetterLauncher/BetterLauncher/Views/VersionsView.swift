import SwiftUI

struct VersionsView: View {
    @EnvironmentObject private var store: VersionStore
    @State private var filter: Filter = .release
    @State private var searchText = ""

    enum Filter: String, CaseIterable, Identifiable {
        case release = "Releases"
        case snapshot = "Snapshots"
        case all = "All"
        var id: String { rawValue }
    }

    private var filtered: [VersionManifest.Entry] {
        store.versions.filter { entry in
            let matchesType: Bool
            switch filter {
            case .release: matchesType = entry.type == "release"
            case .snapshot: matchesType = entry.type == "snapshot"
            case .all: matchesType = true
            }
            let matchesSearch = searchText.isEmpty
                || entry.id.localizedCaseInsensitiveContains(searchText)
            return matchesType && matchesSearch
        }
    }

    var body: some View {
        NavigationStack {
            content
                .navigationTitle("Versions")
                .searchable(text: $searchText)
                .toolbar {
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Picker("Filter", selection: $filter) {
                            ForEach(Filter.allCases) { option in
                                Text(option.rawValue).tag(option)
                            }
                        }
                        .pickerStyle(.menu)
                    }
                }
        }
        .task {
            if store.loadState == .idle {
                await store.load()
            }
        }
    }

    @ViewBuilder
    private var content: some View {
        switch store.loadState {
        case .idle, .loading:
            ProgressView("Loading versions…")
        case .failed(let message):
            VStack(spacing: 12) {
                Text("Couldn't load versions")
                    .font(.headline)
                Text(message)
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                Button("Try again") {
                    Task { await store.load() }
                }
            }
            .padding()
        case .loaded:
            List(filtered) { entry in
                Button {
                    store.selectedID = entry.id
                } label: {
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(entry.id)
                            Text(entry.type.replacingOccurrences(of: "_", with: " ").capitalized)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        if store.selectedID == entry.id {
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundStyle(.tint)
                        }
                    }
                }
                .buttonStyle(.plain)
            }
        }
    }
}
