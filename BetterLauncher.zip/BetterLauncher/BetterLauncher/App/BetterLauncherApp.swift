import SwiftUI

@main
struct BetterLauncherApp: App {
    @StateObject private var versionStore = VersionStore()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(versionStore)
        }
    }
}
